import * as settings from "./preferences/selectors";

export { settings };
