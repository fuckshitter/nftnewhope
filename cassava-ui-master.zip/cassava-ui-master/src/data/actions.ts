import * as settings from "./preferences/actions";

export { settings };
