import * as settings from "./preferences/actionTypes";

export { settings };
