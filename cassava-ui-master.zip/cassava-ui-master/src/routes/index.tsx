import { PureComponent } from "react";

export default class Routes extends PureComponent {
  render() {
    return <></>;
  }
}
